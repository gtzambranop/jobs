# Resolver ejercicios 1, 8, 9, 11

## Ejecución en terminal de Linux

1. Compilar el script `main.cpp` y obtener el ejecutable `main`

  ```bash
  g++ -o main main.cpp
  ```
2. Correr el ejecutable `main`.

  ```bash
  ./main
  ```
