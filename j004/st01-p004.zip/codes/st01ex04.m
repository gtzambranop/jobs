close all
clear; 
clc;

iteraciones = 5000;
intervalo = linspace(0, 4, 1000);

%definicion de las variables a usar
T = 4;                                 %periodo
w = (2 * pi) / T;                      %frecuencia angular

faux = 0;                   
fFinal = 0;
a0 = 5;                                 

for k = 1: iteraciones  

  ak = (10/(k*pi)) * sin(k*w);
  bk = (10/(k*pi)) * (1 - cos(k*w));
  
  %almacena la sumatoria sin el a0
  faux = faux + (ak *cos(k*w*intervalo) + bk * sin(k*w*intervalo) ); 

end 

fFinal = a0/2 + faux;

%valor que se le restar al intervalo de la funcion original
%para que no aparezca una linea vertical en la grafica.
dif = 0.00001;

%intervalo y puntos en el mismo de la funcion original
x = linspace(0 + dif, 4 - dif, 1000);

fOriginal = (10).*((x >= 0) & (x <= 1)) + (0).*((x > 1) & (x <= 4));


figure(1); clf(1)
hold on
plot(x, fOriginal, 'r')
plot(intervalo, fFinal, 'b')
xlabel('eje X')
ylabel('eje Y')
title('Funcion Fourier para un n = 5000')
grid on

