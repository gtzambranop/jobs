close all
clear; 
clc;

iteraciones = 4000;

%intervalo de la función final y los puntos entre este.
intervalo = linspace(-4, 4, 1000);

%definicion de las variables a usar
T = 2*pi;                              %periodo
w = (2 * pi) / T;                      %frecuencia

fAuxiliar = 0;                   
fFinal = 0;
a0 = 0;                                 

for k = 1: iteraciones       %sumatoria
   bk = 2*((-1).^(k+1))/(k);
   
   %almacena la sumatoria sin el a0
   fAuxiliar = fAuxiliar + (bk *sin(k*w*intervalo));
end 

fFinal = a0/2 + fAuxiliar;

%valor que se le restar al intervalo de la funcion original
%para que no aparezca una linea vertical en la grafica.
dif = 0.000001;

%intervalo de la funcion original y puntos en la misma.
x = linspace(-pi + dif, pi - dif, 1000);

fOriginal = x;


figure(1); clf(1)
hold on
plot(x, fOriginal, 'r')
plot(intervalo, fFinal, 'b')
xlabel('eje X')
ylabel('eje Y')
title('Funcion Fourier para un n = 4000')
grid on

