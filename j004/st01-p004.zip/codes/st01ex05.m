close all
clear; 
clc;

iteraciones = 8000;
intervalo = linspace(-2, 2, 1000);

%definicion de las variables a usar
T = 4;                                 %periodo
w = (2 * pi) / T;                      %frecuencia angular

faux = 0;                   
fFinal = 0;
a0 = 9/2;      

for k = 1: iteraciones  

  ak = ((1 -((-1).^(k)))/((k*pi).^2));
  bk = ((-1).^(k + 1) / (k*pi));
  
  %almacena la sumatoria sin el a0
  faux = faux + (ak *cos(k*w*intervalo) + bk * sin(k*w*intervalo) ); 

end 

fFinal = a0/2 + 3*faux;

%valor que se le restar al intervalo de la funcion original
%para que no aparezca una linea vertical en la grafica.
dif = 0.00001;

%intervalo y puntos en el mismo de la funcion original
x = linspace(-2 + dif, 2 - dif, 1000);

faux1 = ((3/2)*x + 3).*((x >= -2) & (x <= 0));
faux2 = (3).*((x >= 0) & (x <= 2));

fOriginal = faux1 + faux2;


figure(1); clf(1)
hold on
plot(x, fOriginal, 'r')
plot(intervalo, fFinal, 'b')
xlabel('eje X')
ylabel('eje Y')
title('Funcion Fourier para un n = 8000')
grid on

