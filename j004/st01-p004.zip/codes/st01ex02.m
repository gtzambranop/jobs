close all
clear; 
clc;

iteraciones = 4000;

%rango y cantidad de puntos en el mismo. Funcion de fourier.
intervalo = linspace(-2, 5, 1000); 

%definicion de las variables a usar
T = 2*pi;           	%periodo
w = (2 * pi) / T;           

ffinal = 0;

%sumatoria
for k = 1: iteraciones       
   ak = (3*sin((k*pi / 2)) - sin((3*pi*k / 2)) )/(pi*k);
   bk = (cos((pi*k / 2)) - cos((3*pi*k / 2)) )/(pi*k);
   
   ffinal = ffinal + ak*cos(k*w*intervalo) + bk*sin(k*w*intervalo);
end 

%valor que se le restar al intervalo de la funcion original
%para que no aparezca una linea vertical en la grafica.
dif = 0.00001;


%rango y cantidad de puntos en el mismpo. Funcion original.
x = linspace(-(pi/2) + dif, (3*pi/2) - dif, 1000);

faux1 = 1.*((x >= -pi/2) & (x <= pi/2));
faux2 = -1.*((x > pi/2) & (x <= (3*pi)/2));

fOriginal = faux1 + faux2;

figure(1); clf(1)
hold on
plot(x, fOriginal, 'r')
plot(intervalo, ffinal, 'b')
xlabel('eje X')
ylabel('eje Y')
title('Funcion Fourier para un n = 4000')
grid on

