close all
clear;

%intervalos y distancia entre punto inicial y final
x1 = 0: 0.005: 4;				%funcion de fourier
x2 = 0: 0.005: 4;		%funcion original

T = 4;		                           %periodo
w = (2 * pi) / T;                      %frecuencia

f_aux = 0;                   
f = 0;
g = 0;
n = 10000;

i = n;

while i > 0	
   a_n = (10/(i*pi)) * sin(i*w);
   b_n = (10/(i*pi)) * (1 - cos(i*w));
         
   f_aux = f_aux + a_n*cos(i*w*x1) + b_n*sin(i*w*x1);
   i = i - 1;
end 

a_0 = 5;

f = a_0 /2 + f_aux;

%definicion funcion a trozos
g1 = (10).*((x2 >= 0) & (x2 <= 1));
g2 = (0).*((x2 > 1) & (x2 <= 4));
	
g = g1 + g2;

figure(1); clf(1)
hold on %permite la graficacion de multiples funciones a la vez

subplot(2,1, 1),plot(x2, g, 'b'), title('Grafica original');
ylim([-5 15]);
xlabel('eje x'),ylabel('eje y'), grid;
subplot(2,1, 2),plot(x1, f, 'm'), title('Grafica f con n = 10000');
ylim([-5 15]);
xlabel('eje x'), ylabel('eje y'), grid;
