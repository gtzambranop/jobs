close all
clear;

%intervalos y distancia entre punto inicial y final
x1 = -4: 0.005: 4;				%funcion de fourier
x2 = -(pi): 0.005: (pi);		%funcion original

T = 2*pi;                              %periodo
w = (2 * pi) / T;                      %frecuencia

f_aux = 0;                   
f = 0;
g = 0;
n = 10000;

i = n;

while i > 0	
   a_n = 2*((-1).^i)/(i.^2);
      
   f_aux = f_aux + a_n*cos(i*w*x1);
   
   i = i - 1;
end 

a_0 = (pi.^2)/3;

f = a_0 /2 + f_aux;

%funcion original
g = ((x2.^2)/2).*((x2 < pi)  & (x2 > -pi));;

figure(1); clf(1)
hold on %permite la graficacion de multiples funciones a la vez

subplot(2,1, 1),plot(x2, g, 'b'), title('Grafica original');
xlabel('eje x'),ylabel('eje y'), grid;
subplot(2,1, 2),plot(x1, f, 'm'), title('Grafica f con n = 10000');
xlabel('eje x'), ylabel('eje y'), grid;
