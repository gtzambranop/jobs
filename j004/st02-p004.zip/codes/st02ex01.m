close all
clear; 

%intervalos y distancia entre punto inicial y final
x1 = -5: 0.005: 5;		%funcion de fourier
x2 = -pi: 0.005: pi;	%funcion original

T = 2*pi;                              %periodo
w = (2 * pi) / T;                      %frecuencia

f_aux = 0;                   
f = 0;
g = 0;
n = 10000;

i = n;

while i > 0
   b_n = 2*((-1).^(i+1))/(i);
   
   f_aux = f_aux + (b_n *sin(i*w*x1));
   i = i - 1;
end 

%como a_0 es cero, la funcion de la sumatoria es la
%funcion final

f = f_aux;

g = x2;

figure(1); clf(1)
hold on %permite la graficacion de multiples funciones a la vez

subplot(2,1, 1),plot(x2, g, 'b'), title('Grafica original');
xlabel('eje x'),ylabel('eje y'), grid;
subplot(2,1, 2),plot(x1, f, 'm'), title('Grafica f con n = 10000');
xlabel('eje x'), ylabel('eje y'), grid;


